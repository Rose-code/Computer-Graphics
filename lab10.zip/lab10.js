var canvas;
var gl;

var numVertices = 36;

var textSize = 4;
var numChecks = 2;

var flag = true;

var image2 = new Uint8Array([255, 0, 0, 255]);

var red = new Uint8Array([0, 255, 0, 255]);
var green = new Uint8Array([0, 255, 0, 255]);
var blue = new Uint8Array([0, 0, 255, 255]);
var cyan = new Uint8Array([0, 255, 255, 255]);
var magenta = new Uint8Array([255, 0, 255, 255]);
var yellow = new Uint8Array([255, 255, 0, 255]);

var cubeMap;

var pointsArray= [];
var normalsArray = [];

var vertices = [
	vec4( -0.5, -0.5, 0.5, 1.0),
	vec4( -0.5, 0.5, 0.5, 1.0),
	vec4( 0.5, 0.5, 0.5, 1.0),
	vec4( 0.5, -0.5, 0.5, 1.0),
	vec4( -0.5, -0.5, -0.5, 1.0),
	vec4( -0.5, 0.5, -0.5, 1.0),
	vec4( 0.5, -0.5, -0.5, 1.0),
];

window.onload = init;

var xAxis = 0;
var yAxis = 1;
var zAxis = 2;
var axis = xAxis;

var theta = [45.0, 45.0, 45.0];

var thetaLoc;

function configureCubeMap() {
	for(var i = 0; i < textSize; i++) {
		for( var j = 0; j < textSize; j++) {
			var c;
			var patchx = Math.floor(i/(textSize/numChecks));
			var patchy = Math.floor(j/(textSize/numChecks));
			if(patchx % 2 != patchy % 2) c = 255;
			else c = 0;
			image2[4 * i * textSize + 4*j] = c;
			image2[4 * i * textSize + 4*j + 1] = c;
			image2[4 * i * textSize + 4*j + 2] = c;
			image2[4 * i * textSize + 4*j + 3] = c;
		}
	}
	cubeMap = gl.createTexture();
	
	gl.bindTexture(gl.TEXTURE_CUBE_MAP, cubeMap);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, red);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, green);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, blue);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, cyan);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, yellow);
	gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA,
	1,1,0,gl.UNSIGNED_BYTE, magenta);
	
	gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
}

function quad(a, b, c, d) {
		var t1 = subtract(vertices[b],vertices[a]);
		var t2 = subtract(vertices[c],vertices[b]);
		var normal = cross(t1, t2);
		normal = normalize(normal);
		
		pointsArray.push(vertices[a]);
		normalsArray.push(normal);
		
		pointsArray.push(vertices[b]);
		normalsArray.push(normal);
		
		pointsArray.push(vertices[c]);
		normalsArray.push(normal);
		
		pointsArray.push(vertices[d]);
		normalsArray.push(normal);
}
function colorCube()
{
	quad(1, 0, 3, 2);
	quad(2, 3, 7, 6);
	quad(3, 0, 4, 7);
	quad(6, 5, 1, 2);
	quad(4, 5, 6, 7);
	quad(5, 4, 0, 1);
}

function init() {
	canvas = document.getElementById("gl-canvas");
	gl = WebGLUtils.setupWebGL(canvas);
	if(!gl) { alert ("WebGL isn't available"); }
	
	gl.viewport(0,0, canvas.width, canvas.height);
	gl.clearColor(1.0, 1.0, 1.0, 1.0);
	
	gl.enable(gl.DEPTH_TEST);
	
	//Load shaders and initialiaze attribute buffers
	//
	var program= initShaders(gl, "vertex-shader", "fragment-shader" );
	gl.useProgram(program);
	
	colorCube();
	
	var nBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, nBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(normalsArray), gl.STATIC_DRAW);
	
	var vNormal = gl.getAttrbLocation(program, "vNormal");
	gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vNormal);
	
	var vBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW);
	
	var vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);
	
	var eye = vec3(0.0, 0.0, 1.0);
	var at = vec3(0.0, 0.0, 0.0);
	var up = vec3(0.0, 1.0, 0.0);
	
	var modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");
	var modelViewMatrix = lookAt(eye, at, up);
	gl.UniformMatrix4fv(modelViewMatrixLoc, false, flatten (modelViewMatrix));
	
	var projectionMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");
	var projectionMatrix = ortho(-2, 2, -2, 2, -10, 10);
	gl.UniformMatrix4fv(projectionMatrixLoc, false, flatten (projectionMatrix));
	
	configureCubeMap();
	gl.activeTexture(gl.TEXTURED);
	gl.uniform1i(gl.getUniformLocation(program, "texMap"),0);
	thetaLoc = gl.getUniformLocation(program, "theta");
	
	document.getElementById("ButtonX").onclick = function() {axis = xAxis;}
	document.getElementById("ButtonY").onclick = function() {axis = yAxis;};
	document.getElementById("ButtonZ").onclick = function() {axis = zAxis;};
	document.getElementById("ButtonT").onclick = function() {flag = !flag;};
	
	render();
}

var render = function() {
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
	if(flag) theta[axis] += 2.0;
	gl.uniform3fv(thetaLoc, theta);
	gl.drawArrays(gl.TRIANGLES, 0, numVertices);
	requestAnimationFrame(render);
}