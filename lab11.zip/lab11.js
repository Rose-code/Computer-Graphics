function init() {
	
	//create a scene, that will hold all our elements such as objects, cameras, and lighting
	var scene = new THREE.Scene();
	
	//create a camera which defines where were looking 
	var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1,
	1000);
	
	//create a render and set the size
	var webGLRenderer = new THREE.WebGLRenderer();
	webGLRenderer.setClearColor(new THREE.Color(0xEEEEEE, 1.0));
	webGLRenderer.setSize(window.innerWidth, window.innerHeight);
	webGLRenderer.shadowMap.enabled = true;
	
	
    var torus = createMesh(new THREE.TorusGeometry(10, 10, 8, 6, Math.PI * 2));
    var initialRadius = 4;
    var initialWidthSegments = 10;
    var initialHeightSegments = 10;
	
	var sphere = createMesh(new THREE.SphereGeometry(initialRadius, initialWidthSegments, initialHeightSegments));
	
	var meshArray = [torus, sphere];
	//add the sphere to the scene
	scene.add(sphere);
	
	//position and point the camera to the center of the scene 
	camera.position.x = -30;
	camera.position.y = 40;
	camera.position.z = 50;
	camera.lookAt(new THREE.Vector3(10, 0, 0));
	
	//add the output of the renderer to the html element
	document.getElementById("WebGL-output").appendChild(webGLRenderer.domElement);
	
	//call the render function
	var step = 0;
	var tick = 0;
	var meshSwitch = 0;
	var currentMesh = meshArray[meshSwitch];
	meshSetup(currentMesh);
	render();
	
}
	function render() {
		step += 0.01;
		torus.rotation.y = step;
		sphere.rotation.y = step;
		
		tick += 1;
		
		if(tick == 50) {
			console.log("Tick = 50, change mesh");
			turnOffMesh(currentMesh);
			scene.remove(currentMesh);
			if( meshSwitch == 0) {
				meshSwitch = 1;
			}
			else {
				meshSwitch = 0;
			}
		currentMesh = meshArray[meshSwitch];
		scene.add(currentMesh);
		meshSetup(currentMesh);
		adjustOpacity(currentMesh, 0);
	}
	else if( tick == 100) {
		console.log('Reset Tick');
		tick = 0;
	}
	else if(tick > 50) {
		var opacity = (tick / 100);
		console.log('Tick: ' + tick + ' - Opacity: ' + opacity);
		adjustOpacity(currentMesh, opacity);
	}
	else {
		var opacity = 1 - (tick / 100);
		console.log('Tick: ' + ' - Opacity: ' + opacity);
		adjustOpacity(currentMesh, opacity);
	}
	
	//render using requestAnimationFrame
	requestAnimationFrame(render);
	webGLRenderer.render(scene, camera);

	}
		
	function updateMaterialProperties(mesh, updateFunction) {
		var meshChildren = mesh.children;
		if( Array.isArray(meshChildren) ) {
			for( var m = 0; m < meshChildren.length; m++) {
				updateFunction(meshChildren[ m ].material);
			}
		} else {
			updateFunction(meshChildren.material);
		}
	}
		
    function turnOffMesh(mesh) {
		 updateMaterialProperties(mesh, function ( mat, value = false) {
			 mat.visible = value;
			 mat.needsUpdate = true;
		});
	}
	
	function meshSetup(mesh) {
		 updateMaterialProperties(mesh, function ( mat, value = true) {
			 mat.transparent = value;
			 mat.visible = value;
			 mat.needsUpdate = true;
		});
	}
	
	function adjustOpacity(mesh, opacity) {
		updateMaterialProperties(mesh, function (mat, value = opacity) {
			mat.opacity = opacity;
			mat.needsUpdata = true;
		});
	}
	
	function createMesh(geom) {
		//assign two materials 
		var meshMaterial = new THREE.MeshNormalMaterial();
		meshMaterial.side = THREE.DoubleSide;
		meshMaterial.transparent = true;
		var wireFrameMat = new THREE.MeshBasicMaterial();
		wireFrameMat.wireframe = true;
		wireFrameMat.transparent = true;
		
		//create a multimaterial
		var mesh = THREE.SceneUtils.createMultiMaterialObject(
									geom,
									[meshMaterial, wireFrameMat]);
			return mesh;
	}
	
	window.onload = init;